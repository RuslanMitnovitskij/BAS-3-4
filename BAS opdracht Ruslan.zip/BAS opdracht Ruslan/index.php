<html>
<!--
	Auteur: Ruslan Mitnovitskij
	Functie: homepagina CRUD klant
-->

<head>
	<link rel="stylesheet" href="styles.css">
</head>

<body>
<?php include 'navbar.php'; ?>

	<h1>Bas opdracht Ruslan</h1>

</body>

</html>